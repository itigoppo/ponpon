# ************************************************************
# Sequel Pro SQL dump
# バージョン 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# ホスト: localhost (MySQL 5.1.71)
# データベース: itigoppo
# 作成時刻: 2014-02-10 02:11:47 +0900
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# テーブルのダンプ acs_blacklist
# ------------------------------------------------------------

DROP TABLE IF EXISTS `acs_blacklist`;

LOCK TABLES `acs_blacklist` WRITE;
/*!40000 ALTER TABLE `acs_blacklist` DISABLE KEYS */;

INSERT INTO `acs_blacklist` (`id`, `user_id`, `status`, `count`)
VALUES
	(1,'5516842',1,0);

/*!40000 ALTER TABLE `acs_blacklist` ENABLE KEYS */;
UNLOCK TABLES;


# テーブルのダンプ acs_blstatus
# ------------------------------------------------------------

DROP TABLE IF EXISTS `acs_blstatus`;

CREATE TABLE `acs_blstatus` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `val` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `acs_blstatus` WRITE;
/*!40000 ALTER TABLE `acs_blstatus` DISABLE KEYS */;

INSERT INTO `acs_blstatus` (`id`, `val`)
VALUES
	(1,'safe'),
	(2,'over'),
	(3,'deny');

/*!40000 ALTER TABLE `acs_blstatus` ENABLE KEYS */;
UNLOCK TABLES;


# テーブルのダンプ acs_contacts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `acs_contacts`;

LOCK TABLES `acs_contacts` WRITE;
/*!40000 ALTER TABLE `acs_contacts` DISABLE KEYS */;

INSERT INTO `acs_contacts` (`id`, `user_id`, `trade_id`, `created`)
VALUES
	(1,'115958635',1,'2014-01-21 12:18:45'),
	(2,'115958635',3,'2014-01-21 15:42:59'),
	(3,'115958635',2,'2014-01-21 16:23:57'),
	(4,'115958635',6,'2014-01-21 16:24:23'),
	(5,'5516842',13,'2014-01-22 01:42:15'),
	(6,'5516842',13,'2014-01-26 18:42:58'),
	(7,'115958635',4,'2014-01-26 18:52:01');

/*!40000 ALTER TABLE `acs_contacts` ENABLE KEYS */;
UNLOCK TABLES;


# テーブルのダンプ acs_denylist
# ------------------------------------------------------------

DROP TABLE IF EXISTS `acs_denylist`;

LOCK TABLES `acs_denylist` WRITE;
/*!40000 ALTER TABLE `acs_denylist` DISABLE KEYS */;

INSERT INTO `acs_denylist` (`id`, `user_id`, `target_id`, `reason`)
VALUES
	(1,'5516842','666',NULL),
	(2,'5516842','3333',NULL);

/*!40000 ALTER TABLE `acs_denylist` ENABLE KEYS */;
UNLOCK TABLES;


# テーブルのダンプ acs_event_times
# ------------------------------------------------------------

DROP TABLE IF EXISTS `acs_event_times`;

CREATE TABLE `acs_event_times` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` int(20) DEFAULT NULL,
  `part` int(10) DEFAULT NULL,
  `time` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `acs_event_times` WRITE;
/*!40000 ALTER TABLE `acs_event_times` DISABLE KEYS */;

INSERT INTO `acs_event_times` (`id`, `event_id`, `part`, `time`)
VALUES
	(1,1,1,'14:00:00'),
	(2,2,1,'15:30:00'),
	(3,2,2,'16:00:00'),
	(4,2,3,'16:30:00'),
	(5,2,4,'17:00:00'),
	(6,3,1,'18:00:00'),
	(7,3,2,'19:00:00'),
	(8,3,3,'20:00:00'),
	(9,4,1,'18:00:00'),
	(10,4,2,'19:00:00'),
	(11,4,3,'20:00:00'),
	(12,5,1,'15:00:00'),
	(13,5,2,'16:00:00'),
	(14,5,3,'17:00:00'),
	(15,5,4,'18:00:00'),
	(16,5,5,'19:00:00'),
	(17,6,1,'15:40:00'),
	(18,6,2,'16:45:00'),
	(19,6,3,'18:10:00'),
	(20,6,4,'19:15:00'),
	(21,7,1,'14:00:00'),
	(22,8,1,'15:30:00'),
	(23,8,2,'16:00:00'),
	(24,8,3,'16:30:00'),
	(25,8,4,'17:00:00'),
	(26,8,5,'18:00:00'),
	(27,8,6,'18:30:00'),
	(28,8,7,'19:00:00'),
	(29,8,8,'19:30:00'),
	(30,9,1,'14:40:00'),
	(31,9,2,'15:45:00'),
	(32,9,3,'16:50:00'),
	(33,9,4,'18:35:00'),
	(34,9,5,'19:40:00'),
	(35,10,1,'14:40:00'),
	(36,10,2,'15:45:00'),
	(37,10,3,'16:50:00'),
	(38,10,4,'18:35:00'),
	(39,10,5,'19:40:00'),
	(40,11,1,'14:00:00'),
	(41,12,1,'15:30:00'),
	(42,12,2,'16:00:00'),
	(43,12,3,'16:30:00'),
	(44,12,4,'17:00:00'),
	(45,12,5,'18:00:00'),
	(46,12,6,'18:30:00'),
	(47,12,7,'19:00:00'),
	(48,12,8,'19:30:00'),
	(49,13,1,'18:00:00'),
	(50,13,2,'19:00:00'),
	(51,13,3,'20:00:00'),
	(52,14,1,'11:00:00'),
	(53,14,2,'12:00:00'),
	(54,14,3,'13:00:00'),
	(55,14,4,'14:30:00'),
	(56,14,5,'15:30:00'),
	(57,14,6,'16:30:00'),
	(58,14,7,'18:00:00'),
	(59,14,8,'19:00:00'),
	(60,15,1,'15:00:00'),
	(61,15,2,'16:00:00'),
	(62,15,3,'17:00:00'),
	(63,15,4,'18:00:00'),
	(64,15,5,'19:00:00'),
	(65,16,1,'13:40:00'),
	(66,17,1,'15:40:00'),
	(67,17,2,'16:45:00'),
	(68,17,3,'18:10:00'),
	(69,17,4,'19:15:00'),
	(70,18,1,'10:30:00'),
	(71,18,2,'11:30:00'),
	(72,18,3,'12:30:00'),
	(73,18,4,'14:00:00'),
	(74,18,5,'15:00:00'),
	(75,19,1,'12:40:00'),
	(76,20,1,'14:40:00'),
	(77,20,2,'15:45:00'),
	(78,20,3,'16:50:00'),
	(79,20,4,'18:35:00'),
	(80,20,5,'19:40:00'),
	(81,21,1,'11:20:00'),
	(82,21,2,'12:40:00'),
	(83,22,1,'14:40:00'),
	(84,22,2,'15:45:00'),
	(85,22,3,'16:50:00'),
	(86,22,4,'18:35:00'),
	(87,22,5,'19:40:00'),
	(88,23,1,'11:20:00'),
	(89,23,2,'12:40:00'),
	(90,24,1,'14:40:00'),
	(91,24,2,'15:45:00'),
	(92,24,3,'16:50:00'),
	(93,24,4,'18:35:00'),
	(94,24,5,'19:40:00'),
	(95,25,1,'11:00:00'),
	(96,25,2,'12:05:00'),
	(97,25,3,'13:10:00'),
	(98,25,4,'14:55:00'),
	(99,25,5,'16:00:00'),
	(100,25,6,'17:05:00'),
	(101,26,1,'13:40:00'),
	(102,27,1,'15:40:00'),
	(103,27,2,'16:45:00'),
	(104,27,3,'18:10:00'),
	(105,27,4,'19:15:00');

/*!40000 ALTER TABLE `acs_event_times` ENABLE KEYS */;
UNLOCK TABLES;


# テーブルのダンプ acs_events
# ------------------------------------------------------------

DROP TABLE IF EXISTS `acs_events`;

CREATE TABLE `acs_events` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `day` date NOT NULL,
  `unit` int(10) NOT NULL,
  `type` int(10) DEFAULT NULL,
  `pref` int(10) DEFAULT '13',
  `place` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `acs_events` WRITE;
/*!40000 ALTER TABLE `acs_events` DISABLE KEYS */;

INSERT INTO `acs_events` (`id`, `day`, `unit`, `type`, `pref`, `place`)
VALUES
	(1,'2014-01-13',4,3,12,'日本青年館 中ホール'),
	(2,'2014-01-13',4,1,12,'日本青年館 中ホール'),
	(3,'2014-01-17',3,1,22,'東別院ホール'),
	(4,'2014-01-24',3,1,12,'時事通信ホール'),
	(5,'2014-01-26',5,1,22,'東別院ホール'),
	(6,'2014-02-02',3,1,26,'御堂会館 南館B1F展示室'),
	(7,'2014-02-08',4,3,26,'ATC特設会場（ITM棟2F)'),
	(8,'2014-02-08',4,1,26,'ATC特設会場（ITM棟2F)'),
	(9,'2014-02-08',3,1,12,'浅草橋ヒューリックホール'),
	(10,'2014-02-09',3,1,12,'浅草橋ヒューリックホール'),
	(11,'2014-02-09',4,3,22,'セントレアホール'),
	(12,'2014-02-09',4,1,22,'セントレアホール'),
	(13,'2014-02-14',3,1,26,'御堂会館 いちょうルーム'),
	(14,'2014-02-22',6,1,12,'ベルサール汐留'),
	(15,'2014-03-01',5,1,26,'御堂会館 南御堂 南館B1F 展示室'),
	(16,'2014-03-02',1,2,26,'ATC特設会場（ITM棟2F）'),
	(17,'2014-03-02',1,1,26,'ATC特設会場（ITM棟2F）'),
	(18,'2014-03-08',5,1,12,'TFMホール'),
	(19,'2014-03-08',1,2,12,'ベルサール汐留'),
	(20,'2014-03-08',1,1,12,'ベルサール汐留'),
	(21,'2014-03-23',1,2,12,'ベルサール汐留'),
	(22,'2014-03-23',1,1,12,'ベルサール汐留'),
	(23,'2014-04-13',1,2,12,'ベルサール渋谷ファースト'),
	(24,'2014-04-13',1,1,12,'ベルサール渋谷ファースト'),
	(25,'2014-04-26',1,1,12,'ベルサール汐留'),
	(26,'2014-05-11',1,2,22,'名古屋国際会議場イベントホール'),
	(27,'2014-05-11',1,1,22,'名古屋国際会議場イベントホール');

/*!40000 ALTER TABLE `acs_events` ENABLE KEYS */;
UNLOCK TABLES;


# テーブルのダンプ acs_members
# ------------------------------------------------------------

DROP TABLE IF EXISTS `acs_members`;

CREATE TABLE `acs_members` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `unit_id` int(10) DEFAULT NULL,
  `member` varchar(50) DEFAULT NULL,
  `short` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `acs_members` WRITE;
/*!40000 ALTER TABLE `acs_members` DISABLE KEYS */;

INSERT INTO `acs_members` (`id`, `unit_id`, `member`, `short`)
VALUES
	(1,1,'道重さゆみ','道重'),
	(2,1,'譜久村聖','譜久村'),
	(3,1,'生田衣梨奈','生田'),
	(4,1,'鞘師里保','鞘師'),
	(5,1,'鈴木香音','鈴木'),
	(6,1,'飯窪春菜','飯窪'),
	(7,1,'石田亜佑美','石田'),
	(8,1,'佐藤優樹','佐藤'),
	(9,1,'工藤遥','工藤'),
	(10,1,'小田さくら','小田'),
	(11,2,'清水佐紀','清水'),
	(12,2,'嗣永桃子','嗣永'),
	(13,2,'徳永千奈美','徳永'),
	(14,2,'須藤茉麻','須藤'),
	(15,2,'夏焼雅','夏焼'),
	(16,2,'熊井友理奈','熊井'),
	(17,2,'菅谷梨沙子','菅谷'),
	(18,3,'矢島舞美','矢島'),
	(19,3,'中島早貴','中島'),
	(20,3,'鈴木愛理','鈴木'),
	(21,3,'岡井千聖','岡井'),
	(22,3,'萩原舞','萩原'),
	(23,4,'和田彩花','和田'),
	(24,4,'福田花音','福田'),
	(25,4,'中西香菜','中西'),
	(26,4,'竹内朱莉','竹内'),
	(27,4,'勝田里奈','勝田'),
	(28,4,'田村芽実','田村'),
	(29,5,'宮崎由加','宮崎'),
	(30,5,'金澤朋子','金澤'),
	(31,5,'高木紗友希','高木'),
	(32,5,'宮本佳林','宮本'),
	(33,5,'植村あかり','植村'),
	(34,6,'宮崎由加','宮崎'),
	(35,6,'金澤朋子','金澤'),
	(36,6,'高木紗友希','高木'),
	(37,6,'宮本佳林','宮本'),
	(38,6,'植村あかり','植村'),
	(39,6,'田辺奈菜美＆浜浦彩乃','田辺&浜浦'),
	(40,6,'吉橋くるみ＆船木結','吉橋&船木'),
	(41,6,'小川麗奈＆山木梨沙','小川&山木'),
	(42,6,'室田瑞希＆牧野真莉愛','室田&牧野'),
	(43,6,'野村みなみ＆和田桜子','野村&和田'),
	(44,6,'佐々木莉佳子＆段原瑠々','佐々木&段原');

/*!40000 ALTER TABLE `acs_members` ENABLE KEYS */;
UNLOCK TABLES;


# テーブルのダンプ acs_trade_status
# ------------------------------------------------------------

DROP TABLE IF EXISTS `acs_trade_status`;

CREATE TABLE `acs_trade_status` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `val` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `acs_trade_status` WRITE;
/*!40000 ALTER TABLE `acs_trade_status` DISABLE KEYS */;

INSERT INTO `acs_trade_status` (`id`, `val`)
VALUES
	(1,'募集中'),
	(2,'取引中'),
	(3,'終了');

/*!40000 ALTER TABLE `acs_trade_status` ENABLE KEYS */;
UNLOCK TABLES;


# テーブルのダンプ acs_trades
# ------------------------------------------------------------

DROP TABLE IF EXISTS `acs_trades`;

LOCK TABLES `acs_trades` WRITE;
/*!40000 ALTER TABLE `acs_trades` DISABLE KEYS */;

INSERT INTO `acs_trades` (`id`, `status`, `user_id`, `event_id`, `de_part`, `de_member`, `mo_part`, `mo_member`, `note`, `contact_cnt`, `created`, `modified`)
VALUES
	(1,2,'5516842',3,7,18,6,19,'',1,'2014-01-16 16:37:17','2014-01-16 16:37:17'),
	(2,2,'5516842',3,6,18,8,19,'tete',1,'2014-01-16 16:38:32','2014-01-21 18:54:41'),
	(3,2,'5516842',3,6,19,6,21,'',1,'2014-01-16 16:50:34','2014-01-16 16:50:34'),
	(4,2,'5516842',17,67,7,66,3,'',1,'2014-01-17 00:46:06','2014-01-17 00:46:06'),
	(5,3,'5516842',17,67,6,68,3,'',0,'2014-01-17 00:46:32','2014-01-17 00:46:32'),
	(6,2,'5516842',13,50,19,50,22,'',1,'2014-01-17 00:46:52','2014-01-17 00:46:52'),
	(7,2,'5516842',15,63,32,61,31,'',0,'2014-01-17 00:47:47','2014-01-17 00:47:47'),
	(8,1,'5516842',11,40,26,40,25,'',0,'2014-01-17 00:48:13','2014-01-17 00:48:13'),
	(9,1,'5516842',13,51,19,51,21,'testらんらんるー',0,'2014-01-17 00:48:56','2014-01-21 18:46:59'),
	(10,1,'5516842',14,53,43,55,42,'',0,'2014-01-17 00:59:21','2014-01-17 00:59:21'),
	(11,1,'5516842',9,32,20,33,21,'',0,'2014-01-17 00:59:53','2014-01-17 00:59:53'),
	(12,1,'5516842',9,33,19,32,21,'',0,'2014-01-17 01:00:10','2014-01-17 01:00:10'),
	(13,2,'115958635',8,23,28,24,28,'まっても∩(･д･)∩',2,'2014-01-17 01:23:43','2014-01-17 01:23:43');

/*!40000 ALTER TABLE `acs_trades` ENABLE KEYS */;
UNLOCK TABLES;


# テーブルのダンプ acs_type
# ------------------------------------------------------------

DROP TABLE IF EXISTS `acs_type`;

CREATE TABLE `acs_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `val` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `acs_type` WRITE;
/*!40000 ALTER TABLE `acs_type` DISABLE KEYS */;

INSERT INTO `acs_type` (`id`, `val`)
VALUES
	(1,'個別握手'),
	(2,'個別チェキ'),
	(3,'お絵描き会');

/*!40000 ALTER TABLE `acs_type` ENABLE KEYS */;
UNLOCK TABLES;


# テーブルのダンプ acs_units
# ------------------------------------------------------------

DROP TABLE IF EXISTS `acs_units`;

CREATE TABLE `acs_units` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `val` varchar(30) DEFAULT NULL,
  `short` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `acs_units` WRITE;
/*!40000 ALTER TABLE `acs_units` DISABLE KEYS */;

INSERT INTO `acs_units` (`id`, `val`, `short`)
VALUES
	(1,'モーニング娘。\'14','モ。'),
	(2,'Berryz工房','ベリ'),
	(3,'℃-ute','℃'),
	(4,'スマイレージ','スマ'),
	(5,'Juice=Juice','J=J'),
	(6,'Juice=Juice+研修生','J+研');

/*!40000 ALTER TABLE `acs_units` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
